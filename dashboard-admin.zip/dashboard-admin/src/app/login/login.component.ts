import { Component, OnInit, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms'; // Import the FormsModule


@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    FormsModule
  ],
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {
    user:any
    pass:any

    constructor(private route:Router){}

    ngOnInit(): void {
      
    }

    login(){
      if(this.user=='admin' && this.pass=='admin'){
          this.route.navigate(['home']);
      }else{
          alert("failed login !! please enter user & password : admin");
      }
    }
}
