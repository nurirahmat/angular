import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-add-employee',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule
  ],
  templateUrl: './add-employee.component.html'
})
export class AddEmployeeComponent {
  constructor(private location: Location) {}

  goBack() {
    this.location.back(); // Use the location.back() method
  }
}
