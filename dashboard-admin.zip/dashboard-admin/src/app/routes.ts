import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { DetailsComponent } from './details/details.component';
import { LoginComponent } from './login/login.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { EditEmployeeComponent } from './edit-employee/edit-employee.component';

const routeConfig: Routes = [
    {
      path: '',
      component: LoginComponent,
      title: 'Login page'
    },
    {
      path: 'home',
      component: HomeComponent,
      title: 'Home page'
    },
    {
      path: 'home/details',
      component: DetailsComponent,
      title: 'Employee details'
    },
    {
      path: 'home/add-employee',
      component: AddEmployeeComponent,
      title: 'Employee details'
    },
    {
      path: 'home/edit-employee',
      component: EditEmployeeComponent,
      title: 'Edit Employee'
    },
    // {
    //   path: 'details/:id',
    //   component: DetailsComponent,
    //   title: 'Home details'
    // }
  ];
  
  export default routeConfig;